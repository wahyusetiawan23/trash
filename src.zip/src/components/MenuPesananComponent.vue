<template>
  <div>
    <div class="content-btn-pesanan">
      <div class="btn-group w-100">
        <router-link to="/bayar" class="btn btn-success" :class="{ active: $route.path === '/bayar' }" exact
          >Menunggu Pembayaran <span v-if="orderCount" class="badge bg-warning text-dark">{{ orderCount }}</span></router-link
        >
        <router-link to="/proses" class="btn btn-success" :class="{ active: $route.path === '/proses' }" exact>Sedang Diproses</router-link>
        <router-link to="/pengiriman" class="btn btn-success" :class="{ active: $route.path === '/pengiriman' }" exact>Dalam Pengiriman</router-link>
        <!-- <router-link to="/batal" class="btn btn-success" :class="{ active: $route.path === '/batal' }" exact>Dibatalkan</router-link> -->
      </div>
    </div>
    <div class="content-list-menu-pesanan">
      <select class="form-select" v-model="accountMenuOption" @change="onChange()">
        <option value="/bayar">Menunggu Pembayaran</option>
        <option value="/proses">Diproses</option>
        <option value="/pengiriman">Dikirim</option>
        <!-- <option value="/batal">Dibatalkan</option> -->
      </select>
    </div>
  </div>
</template>

<script>
import { EventBus } from "@/event-bus";
import api from "@/api";
export default {
  name: "MenuPesananComponent",
  data() {
    return {
      accountMenuOption: "/",
      orderCount: 0,
    };
  },
  created() {
    this.accountMenuOption = this.$router.history.current.fullPath;
    this.getCount();
  },
  methods: {
    onChange() {
      this.$router.push(this.accountMenuOption);
    },
    getCount() {
      // const userInfo = sessionStorage.getItem("token");
      api
        .get("checkout?user_id=" + 1)
        .then((response) => {
          this.checkouts = response.data;
          this.orderCount = this.checkouts.length;
        })
        .catch((error) => {
          console.log(error);
        });
      EventBus.$on("orderUpdated", () => {
        this.orderCount++;
      });
      EventBus.$on("orderDelete", () => {
        this.orderCount--;
      });
    },
  },
  watch: {
    $route(route) {
      this.accountMenuOption = route.path;
    },
  },
};
</script>
