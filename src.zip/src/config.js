export const BASE_URL = "http://localhost/gadget/gadgetcare/upload/";
