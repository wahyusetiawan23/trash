<template>
  <div class="proses">
    <navbar-component />
    <section class="content-pesanan">
      <div class="container">
        <h5 class="title">PESANAN</h5>
        <menu-pesanan-component />
        <div v-if="checkouts.length === 0">
          <div class="empty-wishlist">
            <div class="row">
              <div class="col-md-3">
                <img src="../assets/img/empty.png" alt="" />
              </div>
            </div>
          </div>
          <div class="empty-wishliss mt-3 text-center">
            <router-link to="/product"> <button class="btn btn-wishliss btn-success">Mulai berbelanja</button> </router-link>
          </div>
        </div>
        <div v-else>
          <div class="list-content-pesanan mt-2" v-for="checkout in checkouts" :key="checkout.id">
            <div class="bg-produk-pesanan">
              <div class="row">
                <div class="col-md-2">
                  <p>Dikirm Ke</p>
                </div>
                <div class="col-md-6 ss mb-3">
                  <p>{{ checkout.alamatPengiriman.nama_penerima }} {{ checkout.alamatPengiriman.telepon }} ({{ checkout.alamatPengiriman.nama_alamat }})</p>
                  <p>{{ checkout.alamatPengiriman.alamat_lengkap }}, {{ checkout.alamatPengiriman.kabupaten }}, {{ checkout.alamatPengiriman.provinsi }}</p>
                  <p>{{ checkout.alamatPengiriman.kode_pos }}</p>
                </div>
                <div class="col-md-4">
                  <a href="#" class="btn btn-md btn-success w-100">Konfirmasi Whatsapp</a>
                </div>
              </div>
              <div class="content-produk-pesanan">
                <div class="list-pesanan kemas">
                  <div class="row mt-2" v-for="item in checkout.checkedOutItems" :key="item.id">
                    <div class="col-md-2 col-4 text-center">
                      <img :src="`assets/img/${item.product.image}`" alt="" />
                    </div>
                    <div class="col-md-6 col-8">
                      <div class="produk">
                        <p>{{ item.product.namaProduk }}</p>
                      </div>
                    </div>
                    <div class="col-md-2 text-end">
                      <span class="price-qty">{{ item.product.harga.toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }} x {{ item.quantity }}</span>
                    </div>
                    <div class="col-md-2 text-end">
                      <span class="price">{{ (item.product.harga * item.quantity).toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }}</span>
                    </div>
                  </div>
                </div>
                <div class="ongkir">
                  <div class="row d-flex justify-content-end">
                    <div class="col-md-3 col-6 text-end">
                      <span>Ongkos Kirim {{ checkout.courier.toUpperCase() }} ({{ checkout.cost.description }})</span>
                    </div>
                    <div class="col-md-2 col-6 text-end">
                      <span>{{ checkout.cost.cost[0].value.toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="total-pesanan">
                <div class="row">
                  <div class="col-md-8">
                    <p class="info-pesanan">*Segera lakukan pembayaran dalam 1 x 24 jam, atau pesanan Anda akan Otomatis Dibatalkan.</p>
                  </div>
                  <div class="col-md-4">
                    <div class="bg-total-pesanan">
                      <div class="row d-flex justify-content-end">
                        <div class="col-md-6 col-6 text-end">
                          <span class="title-total">Total Bayar:</span>
                        </div>
                        <div class="col-md-6 col-6 text-end">
                          <span class="total-harga">{{ checkout.totalHarga.toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn-more-pesanan">
                <div class="row">
                  <div class="col-md-2">
                    <a href="#" class="btn w-100 btn-danger" @click="batalkanPesanan(checkout.id)">Batalkan</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import api from "@/api";
import NavbarComponent from "@/components/NavbarComponent.vue";
import Swal from "sweetalert2";
import MenuPesananComponent from "@/components/MenuPesananComponent.vue";
export default {
  components: { NavbarComponent, MenuPesananComponent },
  metaInfo() {
    return {
      title: "Pembayaran Gadgetcare",
    };
  },
  data() {
    return {
      checkouts: [],
      item: [],
    };
  },

  mounted() {
    const userInfo = JSON.parse(sessionStorage.getItem("userInfo"));
    if (userInfo) {
      this.userInfo = userInfo[0];
      api
        .get("checkout?user_id=" + userInfo[0].id)
        .then((response) => {
          this.checkouts = response.data;
        })
        .catch((error) => {
          console.log(error);
        });
    }
  },
  methods: {
    async batalkanPesanan(id) {
      const { isConfirmed } = await Swal.fire({
        title: "Apakah Anda yakin?",
        text: "Anda akan membatalkan pesananan Anda",
        icon: "warning",
        iconColor: "#bf3c3c",
        color: "#fff",
        background: " #00000080",
        showCancelButton: true,
        confirmButtonColor: "#bf3c3c",
        confirmButtonText: "Ya, batal!",
        cancelButtonText: "Tidak",
      });

      if (!isConfirmed) return;

      try {
        const {
          data: { checkedOutItems },
        } = await api.get(`checkout/${id}`);

        await Promise.all(
          checkedOutItems.map(async (item) => {
            const { data: product } = await api.get(`produk/${item.product.id}`);
            product.stok += item.quantity;
            product.sold -= item.quantity;
            await api.put(`produk/${item.product.id}`, product);
          })
        );

        await api.delete(`checkout/${id}`);
        this.$toast.warning("Pesananan anda telah batalkan!", { timeout: 2000 });
        setTimeout(() => {
          const index = this.checkouts.findIndex((item) => item.id === id);
          this.checkouts.splice(index, 1);
          this.$toast.dismiss();
          location.reload();
        }, 2000);
      } catch (error) {
        console.log(error);
      }
    },
  },
};
</script>
