<template>
  <div class="checkout">
    <navbar-component />
    <section class="content-page-kirim">
      <div class="container">
        <div class="content-kirim cek-out">
          <h5 class="title">PEMBAYARAN</h5>
          <div class="row">
            <div class="col-md-7">
              <div class="bg-alamat-kirim" v-if="pengirimDropship">
                <div class="header">Alamat Pengirim</div>
                <div class="content">
                  <p class="name">{{ pengirimDropship.nama }} {{ pengirimDropship.telepon }}</p>
                  <p>{{ pengirimDropship.alamat }}</p>
                </div>
              </div>
              <div class="bg-detail-pesanan" v-if="alamatPengiriman">
                <div class="header">Alamat Pengiriman</div>
                <div class="content">
                  <p class="name">{{ alamatPengiriman.nama_penerima }} ({{ alamatPengiriman.nama_alamat }})</p>
                  <p>{{ alamatPengiriman.telepon }}</p>
                  <p>{{ alamatPengiriman.alamat_lengkap }}, {{ alamatPengiriman.kabupaten }}, {{ alamatPengiriman.kode_pos }}</p>
                  <p>{{ alamatPengiriman.kode_pos }}</p>
                </div>
              </div>
              <div class="bg-detail-pesanan abc">
                <div class="header">Produk Dipesan</div>
                <div class="content" v-for="item in checkedOutItems" :key="item.id">
                  <div class="row">
                    <div class="col-md-2 col-3">
                      <img :src="`../assets/img/${item.product.image}`" alt="" />
                    </div>
                    <div class="col-md-10 col-8">
                      <div class="content-pesanan-detail">
                        <p class="title-produk">{{ item.product.namaProduk }}</p>
                        <p class="total-harga">{{ item.product.harga.toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }} x {{ item.quantity }}</p>
                        <p class="total-harga-produk">{{ (item.product.harga * item.quantity).toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-5">
              <div class="bg-detail-shop">
                <div class="header">Ringkasan Belanja</div>
                <div class="detail-total">
                  <div class="total">
                    <span class="total">Harga</span>
                    <span class="harga">{{ totalHarga }}</span>
                  </div>
                  <div class="total">
                    <span class="total"
                      >Ongkir <span class="fw-bold ms-2"> {{ courier }} </span> ({{ cost.description }})</span
                    >
                    <span class="harga">{{ cost.cost && cost.cost.length ? cost.cost[0].value.toLocaleString("id-ID", { style: "currency", currency: "IDR" }) : "" }}</span>
                  </div>
                </div>
                <div class="total sub">
                  <span class="total">Total Harga</span>
                  <span class="harga">{{ (totalHargaNumeric + ongkirNumeric).toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }}</span>
                </div>
                <div class="btn-detail-bayar">
                  <payment-component/>
                  <a @click="sendDataToApi()" class="btn btn-outline-success">Checkout Whatsapp</a>
                  <a href="#" v-on:click="pay()" class="btn btn-success">Bayar menggunakan midtrans</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>
<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="SB-Mid-client-utWahh74-ME7xS5k"></script>

<script>
// import snap from "@/midtransConfig";
import axios from "axios";
import shortid from "shortid";
import NavbarComponent from "@/components/NavbarComponent.vue";
import PaymentComponent from '@/components/PaymentComponent.vue';
export default {
  components: { NavbarComponent, PaymentComponent },
  metaInfo() {
    return {
      title: "Checkout",
    };
  },
  data() {
    return {
      checkedOutItems: [],
      alamatPengiriman: {},
      pengirimDropship: {},
      courier: [],
      cost: [],
      client: null,
      snapToken: null,
    };
  },
  mounted() {
    const storedItems = JSON.parse(sessionStorage.getItem("checkedOutItems"));
    const data = JSON.parse(sessionStorage.getItem("setAlamat"));
    const couriers = JSON.parse(sessionStorage.getItem("courier"));
    const cost = JSON.parse(sessionStorage.getItem("cost"));

    if (storedItems) {
      this.checkedOutItems = storedItems;
    }
    if (couriers) {
      this.courier = String(couriers);
    }
    if (cost) {
      this.cost = cost;
    }
    if (data) {
      this.alamatPengiriman = data.alamat_pengiriman;
      this.pengirimDropship = data.pengirim_dropship;
    }
  },
  computed: {
    totalHarga() {
      let total = 0;
      this.checkedOutItems.forEach((item) => {
        total += item.product.harga * item.quantity;
      });
      return total.toLocaleString("id-ID", { style: "currency", currency: "IDR" });
    },
    ongkirNumeric() {
      if (this.cost.cost && this.cost.cost.length > 0) {
        return this.cost.cost[0].value;
      }
      return "";
    },
    totalHargaNumeric() {
      let total = 0;
      this.checkedOutItems.forEach((item) => {
        total += item.product.harga * item.quantity;
      });
      return total;
    },
  },
  methods: {
    async sendDataToApi() {
      const transactionId = shortid.generate().toUpperCase();
      const userInfo = JSON.parse(sessionStorage.getItem("userInfo"));
      const payload = {
        id_transaksi: transactionId,
        user_id: userInfo[0].id,
        courier: this.courier,
        cost: this.cost,
        alamatPengiriman: this.alamatPengiriman,
        pengirimDropship: this.pengirimDropship,
        checkedOutItems: this.checkedOutItems,
        totalHarga: this.totalHargaNumeric + this.ongkirNumeric,
      };

      try {
        const response = await axios.post("http://localhost:3004/checkout", payload);
        response.data;
        for (const item of payload.checkedOutItems) {
          const product_id = item.id;
          const product_ids = item.product.id;
          const quantity = item.quantity;
          const sold = item.product.sold;

          await axios.delete(`http://localhost:3004/cart/${product_id}`);

          const response = await axios.get(`http://localhost:3004/produk/${product_ids}`);
          const product = response.data;
          product.stok -= quantity;
          product.sold = sold + quantity;
          await axios.put(`http://localhost:3004/produk/${product_ids}`, product);
        }

        this.$toast.success("Silahkan lakukan pembayaran", {
          timeout: 2000,
        });
        setTimeout(() => {
          this.$toast.dismiss();
          sessionStorage.removeItem("checkedOutItems");
          sessionStorage.removeItem("setAlamat");
          sessionStorage.removeItem("courier");
          sessionStorage.removeItem("cost");
          this.$router.push("/bayar");
          location.reload();
        }, 2000);
      } catch (error) {
        console.error("Error sending data to API:", error);
      }
    },
  },
};
</script>
