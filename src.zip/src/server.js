const express = require("express");
const cors = require("cors");
const midtransClient = require("midtrans-client");

const app = express();
const port = 3000;

const snap = new midtransClient.Snap({
  isProduction: false,
  serverKey: "SB-Mid-server-GqiPUxyw2WnOuYI5XuxQvX-d",
  clientKey: "SB-Mid-client-utWahh74-ME7xS5k",
});
app.use(cors());
app.use(express.json());
let orders = [];
app.post("/transaction", (req, res) => {
  const { orderId, grossAmount, nama, telepon, citi, prov, pos } = req.body;
  const transactionDetails = {
    order_id: orderId,
    gross_amount: grossAmount,
    currency: "IDR",
    transaction_details: {
      order_id: orderId,
      gross_amount: grossAmount,
    },
    customer_details: {
      first_name: nama,
      phone: telepon,
      email: "wahyusetiawan.ws33@gmail.com",
      address: citi,
      shipping_address: {
        first_name: nama,
        phone: telepon,
        address: citi,
        city: prov,
        postal_code: pos,
        country_code: "IDN",
      },
    },
  };

  snap
    .createTransaction(transactionDetails)
    .then((transaction) => {
      orders.push({
        id_order: transactionDetails.order_id,
      });
      res.send({ token: transaction.token });
    })
    .catch((error) => {
      console.log(error);
      res.status(500).send({ message: "Failed to create transaction" });
    });
});

app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
