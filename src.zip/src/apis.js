import axios from "axios";

const apis = axios.create({
  baseURL: "http://localhost/jwt-gadget/v1",
});

export default {
  apis,
  AuthPath: "/Auth", //login. daftar
  ContentPath: "/Privates", //navbar
  PublicPath: "/Publics", //navbar
};
