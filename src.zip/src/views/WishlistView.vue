<template>
  <div class="wishlist">
    <navbar-component />
    <section class="content-wishlist">
      <div class="container">
        <h5 class="title">WISHLIST</h5>
        <div v-if="wishlist.length === 0">
          <div class="empty-wishlist">
            <div class="row">
              <div class="col-md-3">
                <img src="../assets/img/empty.png" alt="" />
              </div>
            </div>
          </div>
          <div class="empty-wishliss mt-3 text-center">
            <router-link to="/product"> <button class="btn btn-wishliss btn-success">Mulai berbelanja</button> </router-link>
          </div>
        </div>
        <div v-else class="card-content">
          <div class="row-container">
            <div class="product-card" v-for="item in wishlist" :key="item.id">
              <div class="card">
                <img v-img :src="'../assets/img/' + item.product.image[0]" class="card-img-top image" alt="..." />
                <div class="card-body">
                  <router-link :to="'/detail/' + item.product.id">
                    <h5 class="card-title" id="myText" data-toggle="tooltip" data-placement="top" :title="item.product.namaProduk">{{ item.product.namaProduk }}</h5>
                    <div class="harga">
                      <h5>{{ item.product.harga }}</h5>
                      <div class="row">
                        <div class="col-md-6 col-5 rating">
                          <font-awesome-icon icon="fa-solid fa-star" /><span class="px-1">{{ item.product.grade }}</span>
                        </div>
                        <div class="col-md-6 col-7 rating d-flex justify-content-end">
                          <font-awesome-icon icon="fa-solid fa-bag-shopping" /><span class="px-1">{{ formattedSold(item.product.sold) }} Terjual</span>
                        </div>
                      </div>
                    </div>
                  </router-link>
                  <div class="btn-wishlist">
                    <div class="row">
                      <div class="col-md-6 col-6">
                        <a class="btn btn-success" :disabled="item.addToCartClicked" @click="addToCart(item.product)" id="add-to-cart-1"><font-awesome-icon icon="fa-solid fa-cart-plus" /></a>
                      </div>
                      <div class="col-md-6 col-6">
                        <a class="btn btn-danger" @click="removeProductFromWishlist(item.id)"><font-awesome-icon icon="fa-solid fa-trash-can" /></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import api from "@/api";
import { EventBus } from "@/event-bus";
import Swal from "sweetalert2";
import NavbarComponent from "@/components/NavbarComponent.vue";
import router from "@/router";
export default {
  components: { NavbarComponent },
  metaInfo() {
    return {
      title: "Wishlist anda di Gadgetcare",
    };
  },
  data() {
    return {
      wishlist: [],
      quantity: 1,
      item: {
        addToCartClicked: false,
      },
    };
  },
  created() {
    // const token = sessionStorage.getItem("token");
    // const decoded = jwt_decode(token);
    // if (token) {
    //   this.userInfo = decoded;
    api
      .get("wishlist?user_id=1")
      .then((response) => {
        this.wishlist = response.data;
      })
      .catch((error) => {
        console.log(error);
      });
    // }
  },
  methods: {
    formattedSold(sold) {
      const number = sold;
      if (number >= 1000000000) {
        return (number / 1000000000).toFixed(0).replace(/\.0$/, "") + "M+";
      } else if (number >= 1000000) {
        return (number / 1000000).toFixed(0).replace(/\.0$/, "") + "jt+";
      } else if (number >= 10000) {
        return (number / 1000).toFixed(0).replace(/\.0$/, "") + "rb+";
      } else if (number >= 1000) {
        return (number / 1000).toFixed(1).replace(/\.0$/, "") + "rb+";
      } else {
        return number.toString();
      }
    },
    addToCart(item) {
      if (item.addToCartClicked) {
        return;
      }

      item.addToCartClicked = true;
      if (!sessionStorage.getItem("userInfo")) {
        this.$toast.error("Anda harus login terlebih dahulu");
        router.push("/login");
        return;
      }

      const userInfo = JSON.parse(sessionStorage.getItem("userInfo"));
      const user_id = userInfo[0].id;

      (async () => {
        try {
          const response = await api.get(`cart?user_id=${user_id}`);
          const cart = response.data;
          const existingCartItem = cart.find((i) => i.product.id === item.id);

          if (existingCartItem) {
            const totalQuantity = existingCartItem.quantity + parseInt(this.quantity);

            if (totalQuantity > existingCartItem.product.stok) {
              this.$toast.error("Dikeranjang belanja anda sudah ada produk yang sama, setelah dijumlahkan melebihi stok yang tersedia");
              return;
            }

            existingCartItem.quantity += this.quantity;

            await api.put(`cart/${existingCartItem.id}`, {
              user_id: user_id,
              product: item,
              quantity: existingCartItem.quantity,
            });

            const responseWishlist = await api.get(`wishlist?user_id=${user_id}`);
            const wishlist = responseWishlist.data;
            const wishlistItem = wishlist.find((i) => i.product.id === item.id);

            if (wishlistItem) {
              await api.delete(`wishlist/${wishlistItem.id}`);
            }

            this.$toast.success("Produk berhasil diperbaharui ke keranjang", { timeout: 2000 });

            setTimeout(() => {
              this.$toast.dismiss();
              EventBus.$emit("cartUpdated");
              this.$router.push("/cart");
            }, 2000);
          } else {
            await api.post("cart", {
              user_id: user_id,
              product: item,
              quantity: parseInt(this.quantity),
            });

            const responseWishlist = await api.get(`wishlist?user_id=${user_id}`);
            const wishlist = responseWishlist.data;
            const wishlistItem = wishlist.find((i) => i.product.id === item.id);

            if (wishlistItem) {
              await api.delete(`wishlist/${wishlistItem.id}`);
            }

            this.$toast.success("Produk berhasil dimasukkan ke keranjang", { timeout: 2000 });

            setTimeout(() => {
              this.$toast.dismiss();
              if (this.$router.currentRoute.path !== "/cart") {
                this.$router.push("/cart");
              }
              EventBus.$emit("cartUpdated");
            }, 2000);
          }
        } catch (error) {
          console.log(error);
        }
      })();
    },

    removeProductFromWishlist(id) {
      Swal.fire({
        title: "Apakah Anda yakin?",
        text: "Anda akan menghapus item produk wishlist Anda",
        icon: "warning",
        iconColor: "#bf3c3c",
        color: "#fff",
        background: " #00000080",
        showCancelButton: true,
        confirmButtonColor: "#bf3c3c",
        confirmButtonText: "Ya, hapus!",
        cancelButtonText: "Tidak",
      }).then((result) => {
        if (result.isConfirmed) {
          api
            .delete(`wishlist/${id}`)
            .then(() => {
              this.$toast.success("Produk berhasil dihapus dari wishlist", {
                timeout: 2000,
              });
              setTimeout(() => {
                const index = this.wishlist.findIndex((item) => item.id === id);
                this.wishlist.splice(index, 1);
                this.$toast.dismiss();
                EventBus.$emit("wishlistDelete");
              }, 2000);
            })
            .catch((error) => {
              console.log(error);
            });
        }
      });
    },
  },
};
</script>
