<template>
  <div>
    <div class="btn-alamat">
      <a href="" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#modalAlamat"> <font-awesome-icon icon="fa-solid fa-circle-plus" size="lg" /><span>Tambah Alamat</span> </a>
    </div>
    <div class="modal fade modal-alamat" id="modalAlamat" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Informasi Alamat</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="mb-2">
              <label for="nama_alamat" class="form-label">Nama Alamat</label>
              <!-- <input type="text" class="form-control" id="nama_alamat" v-model="namaAlamat" placeholder="Rumah, Apartemen, atau Kantor" /> -->
              <select id="fruit" class="form-select" v-model="namaAlamat">
                <option value="" disabled>-- Pilih Label Alamat --</option>
                <option v-for="alamat in alamats" :key="alamat.id" :value="alamat.id">{{ alamat.name }}</option>
              </select>
            </div>
            <div class="mb-2">
              <label for="nama" class="form-label">Nama Penerima</label>
              <input type="text" class="form-control" id="nama" maxlength="50" v-model="nama" placeholder="Nama Lengkap Penerima" />
            </div>
            <div class="mb-2">
              <label for="telepon" class="form-label">Nomor Telepon</label>
              <input type="text" class="form-control" id="telepon" maxlength="14" v-model="telepon" placeholder="Contoh: 081799998787" />
            </div>
            <div class="mb-2">
              <label for="provinsi" class="form-label">Provinsi</label>
              <select class="form-select" id="provinsi" v-model="provinsi" @change="getKabupatenList">
                <option value="">Pilih Provinsi</option>
                <option v-for="provinsi in provinsiList" :value="provinsi.province_id" :key="provinsi.province_id">{{ provinsi.province }}</option>
              </select>
            </div>
            <div class="mb-2">
              <label for="kabupaten" class="form-label">Kabupaten</label>
              <select class="form-select" id="kabupaten" v-model="kabupaten" disabled>
                <option value="">Pilih Kabupaten</option>
                <option v-for="item in kabupatenList" :value="item.city_id" :key="item.city_id">{{ item.city_name }}</option>
              </select>
            </div>
            <div class="mb-2">
              <label for="alamat" class="form-label">Alamat Lengkap</label>
              <textarea class="form-control" id="alamat" v-model="alamat" maxlength="200" placeholder="Contoh: Jalan Sudirman no.17" rows="2"></textarea>
            </div>
            <div class="mb-2">
              <label for="pos" class="form-label">Kode Pos</label>
              <input type="text" class="form-control" id="pos" v-model="pos" maxlength="5" placeholder="5 digit" />
            </div>
            <div class="form-check mb-2">
              <label>
                <input type="checkbox" class="checkbox form-check-input" v-model="utama" value="" />
                <span>Jadikan Alamat Utama</span>
              </label>
            </div>
            <div class="btn-modal-alamat">
              <a href="" v-if="disabled" class="btn btn-success disabled">Tunggu Beberapa Saat..</a>
              <a href="" v-else class="btn btn-success" @click.prevent="simpanAlamat">Simpan Alamat</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import api from "@/api";
export default {
  name: "ButtonAddAlamatComponent",
  data() {
    return {
      namaAlamat: "",
      nama: "",
      telepon: "",
      alamat: "",
      pos: "",
      utama: false,
      provinsi: "",
      kabupaten: "",
      provinsiList: [],
      kabupatenList: [],
      apiKey: "4352909653b2b207507bad78b987761b",
      disabled: false,
      alamats: [
        { id: "Rumah", name: "Rumah" },
        { id: "Apartemen", name: "Apartemen" },
        { id: "Kantor", name: "Kantor" },
      ],
    };
  },
  created() {
    this.getProvinces();
  },
  methods: {
    async getProvinces() {
      try {
        const response = await axios.get(`http://localhost:8080/https://api.rajaongkir.com/starter/province`, {
          headers: {
            key: this.apiKey,
          },
        });
        this.provinsiList = response.data.rajaongkir.results;
      } catch (error) {
        console.error(error);
      }
    },
    async getKabupatenList() {
      try {
        const response = await axios.get(`http://localhost:8080/https://api.rajaongkir.com/starter/city?province=${this.provinsi}`, {
          headers: {
            key: this.apiKey,
          },
        });
        this.kabupatenList = response.data.rajaongkir.results;
        const kabupatenSelect = document.getElementById("kabupaten");
        kabupatenSelect.disabled = false;
      } catch (error) {
        console.log(error);
      }
    },
    simpanAlamat: async function () {
      this.disabled = true;
      if (this.namaAlamat === "" || this.nama === "" || this.telepon === "" || this.alamat === "" || this.pos === "") {
        this.$toast.error("Data belum lengkap", {
          timeout: 2000,
        });
        return;
      }
      if (!this.telepon.match(/^(08|62)\d+$/)) {
        this.$toast.error("Nomor Handphone harus diawali dengan 08 atau 62", {
          timeout: 2000,
        });
        return;
      }

      if (isNaN(this.telepon)) {
        this.$toast.error("Nomor Handphone harus berupa angka", {
          timeout: 2000,
        });
        return;
      }

      if (isNaN(this.pos)) {
        this.$toast.error("Kode Pos harus berupa angka", {
          timeout: 2000,
        });
        return;
      }
      // const userInfo = sessionStorage.getItem("token");
      // const decoded = jwt_decode(userInfo);
      // const user_id = decoded.id;
      try {
        const response = await api.get(`alamat_user?user_id=1&utama=true`);
        const existingPrimaryAddress = response.data[0];

        if (existingPrimaryAddress && this.utama) {
          await api.patch(`alamat_user/${existingPrimaryAddress.id}`, { utama: false });
          console.log("Existing primary address updated to false");
        }
        const responseProvinsi = await axios.get(`http://localhost:8080/https://api.rajaongkir.com/starter/province?id=${this.provinsi}`, {
          headers: {
            key: this.apiKey,
          },
        });
        const provinsiDetail = responseProvinsi.data.rajaongkir.results;

        const responseKabupaten = await axios.get(`http://localhost:8080/https://api.rajaongkir.com/starter/city?id=${this.kabupaten}`, {
          headers: {
            key: this.apiKey,
          },
        });
        const kabupatenDetail = responseKabupaten.data.rajaongkir.results;

        await api.post("alamat_user", {
          user_id: 1,
          nama_alamat: this.namaAlamat,
          nama_penerima: this.nama,
          telepon: this.telepon,
          alamat_lengkap: this.alamat,
          kode_pos: this.pos,
          provinsi: provinsiDetail.province,
          kabupaten: kabupatenDetail.type + " " + kabupatenDetail.city_name,
          province_id: this.provinsi,
          city_id: this.kabupaten,
          utama: this.utama,
        });

        this.$toast.success("Alamat berhasil ditambahkan", {
          timeout: 2000,
        });

        setTimeout(() => {
          this.$toast.dismiss();
          location.reload();
        }, 2000);
      } catch (error) {
        console.log(error);
        if (error.response.status === 404) {
          alert("Alamat tidak ditemukan");
        } else {
          alert("Terjadi kesalahan saat menyimpan alamat");
        }
      }
    },
  },
};
</script>
<style></style>
