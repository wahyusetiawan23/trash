<template>
  <div class="akun">
    <navbar-component />
    <section class="content-page-akun">
      <div class="container">
        <div class="content-akun">
          <h5 class="title">AKUN SAYA</h5>
          <div class="row">
            <div class="col-md-3">
              <MenuAkunComponent />
            </div>
            <div class="col-md-9">
              <div class="card-content-alamat">
                <div class="header-alamat">
                  <div class="title-header">Alamat Saya</div>
                  <button-add-alamat-component v-if="alamatList.length < 4" />
                </div>
                <div class="content-alamat">
                  <div class="content" v-for="alamat in alamatList" :key="alamat.id">
                    <div class="row">
                      <div class="col-md-8 col-7 col-alamat">
                        <div class="title">
                          <p class="nama">{{ alamat.nama_alamat }}</p>
                          <p class="contact">
                            <span>{{ alamat.nama_penerima }}</span> {{ alamat.telepon }}
                          </p>
                          <p class="alamat">{{ alamat.alamat_lengkap }}, {{ alamat.kabupaten }}, {{ alamat.provinsi }}</p>
                          <p class="alamat">{{ alamat.kode_pos }}</p>
                          <span class="badge text-bg-success" v-if="alamat.utama">Alamat Utama</span>
                        </div>
                      </div>
                      <div class="col-md-4 col-5 content-btn-alamat">
                        <div class="btn-detail-alamat">
                          <a class="btn btn-sm btn-warning me-1" data-bs-toggle="modal" data-bs-target="#modalEdit" @click="alamatmodal = alamat">
                            <font-awesome-icon icon="fa-solid fa-pen-to-square" />
                          </a>
                          <a class="btn btn-sm btn-danger" @click="hapusAlamat(alamat.id)"><font-awesome-icon icon="fa-solid fa-trash-can" /></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <div class="modal fade modal-alamat" id="modalEdit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Edit Alamat</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="mb-2">
              <label for="nama_alamat" class="form-label">Nama Alamat</label>
              <select class="form-select" id="nama_alamat" v-model="alamatmodal.nama_alamat">
                <option :value="alamatmodal.nama_alamat" :selected="alamatmodal.nama_alamat" disabled>{{ alamatmodal.nama_alamat }}</option>
                <option v-for="alamat in alamats" :key="alamat.id" :value="alamat.name">{{ alamat.name }}</option>
              </select>
            </div>

            <div class="mb-2">
              <label for="nama" class="form-label">Nama Penerima</label>
              <input type="text" class="form-control" id="nama" v-model="alamatmodal.nama_penerima" />
            </div>
            <div class="mb-2">
              <label for="telepon" class="form-label">Nomor Telepon</label>
              <input type="number" class="form-control" id="telepon" v-model="alamatmodal.telepon" />
            </div>
            <div class="mb-2">
              <label for="provinsi" class="form-label">Provinsi</label>
              <select class="form-select" id="provinsi" v-model="alamatmodal.province_id" @change="getKabupatenList">
                <option disabled>{{ alamatmodal.provinsi }}</option>
                <option v-for="provinsi in provinsiList" :value="provinsi.province_id" :key="provinsi.province_id">{{ provinsi.province }}</option>
              </select>
            </div>
            <div class="mb-2">
              <label for="kabupaten" class="form-label">Kabupaten</label>
              <select class="form-select" id="kabupaten" v-model="alamatmodal.kabupaten" @change="getCityId">
                <option :value="alamatmodal.kabupaten" :selected="alamatmodal.kabupaten" disabled>{{ alamatmodal.kabupaten }}</option>
                <option v-for="item in kabupatenList" :value="item.city_name" :key="item.city_id">{{ item.city_name }}</option>
              </select>
            </div>
            <div class="mb-2">
              <label for="alamat" class="form-label">Alamat Lengkap</label>
              <textarea class="form-control" id="alamat" v-model="alamatmodal.alamat_lengkap"></textarea>
            </div>
            <div class="mb-2">
              <label for="pos" class="form-label">Kode Pos</label>
              <input type="number" class="form-control" id="pos" v-model="alamatmodal.kode_pos" />
            </div>
            <div class="form-check mb-2">
              <label>
                <input type="checkbox" class="checkbox form-check-input" v-model="alamatmodal.utama" value="" />
                <span>Jadikan Alamat Utama</span>
              </label>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <a href="" v-if="disabled" class="btn btn-success disabled">Tunggu Beberapa Saat..</a>
            <button v-else type="button" class="btn btn-success" @click="editAlamat">Save changes</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Swal from "sweetalert2";
import MenuAkunComponent from "@/components/MenuAkunComponent.vue";
import NavbarComponent from "@/components/NavbarComponent.vue";
import ButtonAddAlamatComponent from "@/components/ButtonAddAlamatComponent.vue";
import api from "@/api";
import axios from "axios";
export default {
  components: { MenuAkunComponent, NavbarComponent, ButtonAddAlamatComponent },
  metaInfo() {
    return {
      title: "Alamat anda di Gadgetcare",
    };
  },
  data() {
    return {
      type: "password",
      userInfo: "",
      alamatmodal: "",
      alamatList: [],
      disabled: false,
      alamats: [
        { id: "Rumah", name: "Rumah" },
        { id: "Apartemen", name: "Apartemen" },
        { id: "Kantor", name: "Kantor" },
      ],
      provinsiList: [],
      kabupatenList: [],
      apiKey: "4352909653b2b207507bad78b987761b",
    };
  },
  created() {
    // const userInfo = sessionStorage.getItem("token");
    // const decoded = 1;
    // if (userInfo) {
    //   this.userInfo = decoded;
    api
      .get("alamat_user?user_id=1")
      .then((response) => {
        this.alamatList = response.data;
        this.alamatList.sort((a, b) => {
          if (a.utama && !b.utama) {
            return -1;
          } else if (!a.utama && b.utama) {
            return 1;
          } else {
            return 0;
          }
        });
      })
      .catch((error) => {
        console.log(error);
      });
    // }
    this.getProvinces();
  },
  methods: {
    async getProvinces() {
      try {
        const response = await axios.get(`http://localhost:8080/https://api.rajaongkir.com/starter/province`, {
          headers: {
            key: this.apiKey,
          },
        });
        this.provinsiList = response.data.rajaongkir.results;
      } catch (error) {
        console.error(error);
      }
    },
    async getKabupatenList() {
      try {
        const response = await axios.get(`http://localhost:8080/https://api.rajaongkir.com/starter/city?province=${this.alamatmodal.province_id}`, {
          headers: {
            key: this.apiKey,
          },
        });

        this.kabupatenList = response.data.rajaongkir.results;
      } catch (error) {
        console.log(error);
      }
    },
    hapusAlamat(id) {
      Swal.fire({
        title: "Apakah Anda yakin?",
        text: "Anda akan menghapus alamat Anda",
        icon: "warning",
        iconColor: "#bf3c3c",
        color: "#fff",
        background: " #00000080",
        showCancelButton: true,
        confirmButtonColor: "#bf3c3c",
        confirmButtonText: "Ya, hapus!",
        cancelButtonText: "Tidak",
      }).then((result) => {
        if (result.isConfirmed) {
          api
            .delete(`alamat_user/${id}`)
            .then(() => {
              this.$toast.warning("Alamat berhasil dihapus", {
                timeout: 2000,
              });
              setTimeout(() => {
                this.$toast.dismiss();
                const index = this.alamatList.findIndex((alamat) => alamat.id === id);
                this.alamatList.splice(index, 1);
                location.reload();
              }, 2000);
            })
            .catch((error) => {
              console.log(error);
            });
        }
      });
    },
    getCityId() {
      const selectedKabupaten = this.kabupatenList.find((item) => item.city_name === this.alamatmodal.kabupaten);
      if (selectedKabupaten) {
        this.alamatmodal.city_id = selectedKabupaten.city_id;
      }
    },
    editAlamat: async function () {
      this.disabled = true;
      await this.getCityId();
      // const userInfo = sessionStorage.getItem("token");
      // const decoded = jwt_decode(userInfo);

      try {
        const response = await api.get(`alamat_user?user_id=1&utama=true`);
        const existingPrimaryAddress = response.data[0];

        if (existingPrimaryAddress && this.alamatmodal.utama) {
          await api.patch(`alamat_user/${existingPrimaryAddress.id}`, { utama: false });
          console.log("Existing primary address updated to false");
        }
        const responseProvinsi = await axios.get(`http://localhost:8080/https://api.rajaongkir.com/starter/province?id=${this.alamatmodal.province_id}`, {
          headers: {
            key: this.apiKey,
          },
        });
        const provinsiDetail = responseProvinsi.data.rajaongkir.results;
        await api.put(`alamat_user/${this.alamatmodal.id}`, {
          user_id: 1,
          nama_alamat: this.alamatmodal.nama_alamat,
          nama_penerima: this.alamatmodal.nama_penerima,
          telepon: this.alamatmodal.telepon,
          alamat_lengkap: this.alamatmodal.alamat_lengkap,
          kode_pos: this.alamatmodal.kode_pos,
          provinsi: provinsiDetail.province,
          kabupaten: this.alamatmodal.kabupaten,
          province_id: this.alamatmodal.province_id,
          city_id: this.alamatmodal.city_id,
          utama: this.alamatmodal.utama,
        });

        this.$toast.success("Alamat berhasil diperbaharui", {
          timeout: 2000,
        });

        setTimeout(() => {
          this.$toast.dismiss();
          location.reload();
        }, 2000);
      } catch (error) {
        console.log(error);
        if (error.response.status === 404) {
          alert("Alamat tidak ditemukan");
        } else {
          alert("Terjadi kesalahan saat memperbaharui alamat");
        }
      }
    },
  },
};
</script>
