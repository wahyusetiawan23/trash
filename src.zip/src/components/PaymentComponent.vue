<template>
  <div>
    <input type="text" v-model="snapToken" class="form-input" />
    <button @click="pay" class="btn btn-primary input-group-btn">Proceed to Payment</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      snapToken: "1eb34882-290d-4dc5-9f36-3cf35989096b",
    };
  },
  methods: {
    pay() {
      window.snap.pay(this.snapToken);
    },
  },
  mounted() {
    var script = document.createElement("script");
    script.src = "https://app.sandbox.midtrans.com/snap/snap.js";
    script.setAttribute("data-client-key", "SB-Mid-client-61XuGAwQ8Bj8LxSS");
    script.async = true;
    document.head.appendChild(script);
  },
};
</script>
