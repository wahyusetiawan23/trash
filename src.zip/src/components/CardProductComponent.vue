<template>
  <div>
    <div class="card">
      <div class="ribbon">
        <a class="add-to-wishlist" @click="addToWishlist(product)" data-toggle="tooltip" data-placement="top" title="Masukkan Whislist">
          <font-awesome-icon :icon="['fa-solid', 'fa-heart']" :class="{ 'text-warning': product.inWishlist }" />
        </a>
      </div>
      <img v-img :src="`${BASE_URL}produk/${product.foto_1}`" class="card-img-top image" alt="..." loading="lazy" />
      <div class="card-body">
        <router-link :to="'/detail/' + product.id_g_produk">
          <h5 class="card-title" id="myText" data-toggle="tooltip" data-placement="top" :title="product.nama_produk">{{ product.nama_produk }}</h5>
          <div class="harga">
            <h5>{{ Number(product.harga_jual).toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }}</h5>
            <div class="row">
              <div class="col-md-4 col-4 rating">
                <font-awesome-icon icon="fa-solid fa-star" /><span class="px-1">{{ product.grade }}</span>
              </div>
              <div class="col-md-8 col-8 rating d-flex justify-content-end">
                <font-awesome-icon icon="fa-solid fa-bag-shopping" /><span class="px-1">{{ formattedSold }} Terjual</span>
              </div>
            </div>
          </div>
        </router-link>
        <a class="btn btn-cart btn-success add-to-cart-button disabled" v-if="product.stok == 0"><font-awesome-icon icon="fa-solid fa-cart-plus" />STOK HABIS</a>
        <a class="btn btn-cart btn-success add-to-cart-button" v-else @click="addToCart(product)"><font-awesome-icon icon="fa-solid fa-cart-plus" />Keranjang</a>
      </div>
    </div>
  </div>
</template>

<script>
import { BASE_URL } from "@/config";
// import jwt_decode from "jwt-decode";
import router from "@/router";
import { EventBus } from "@/event-bus.js";
import api from "@/api";
// import store from "@/store";
export default {
  name: "CardProductComponent",
  props: ["product"],
  data() {
    return {
      cart: [],
      products: [],
      wishlistCount: 0,
      quantity: 1,
      wishlist: [],
      BASE_URL,
    };
  },
  computed: {
    formattedSold() {
      const number = this.product.terjual;
      if (number >= 1000000000) {
        return (number / 1000000000).toFixed(0).replace(/\.0$/, "") + "M+";
      } else if (number >= 1000000) {
        return (number / 1000000).toFixed(0).replace(/\.0$/, "") + "jt+";
      } else if (number >= 10000) {
        return (number / 1000).toFixed(0).replace(/\.0$/, "") + "rb+";
      } else if (number >= 1000) {
        return (number / 1000).toFixed(1).replace(/\.0$/, "") + "rb+";
      } else {
        return number.toString();
      }
    },
  },
  methods: {
    async addToCart(product) {
      const userInfo = sessionStorage.getItem("trash");
      // const decoded = jwt_decode(userInfo);
      if (!userInfo) {
        this.$toast.info("Anda harus login dulu");
        setTimeout(() => {
          this.$toast.dismiss();
          router.push("/login");
        }, 2000);
        return;
      }
      const user_id = 1;
      try {
        const response = await api.get(`cart?user_id=${user_id}`);
        const cart = response.data;
        const existingCartItem = cart.find((i) => i.product.id === product.id);

        if (existingCartItem) {
          const totalQuantity = existingCartItem.quantity + parseInt(this.quantity);
          if (totalQuantity > existingCartItem.product.stok) {
            this.$toast.error("Dikeranjang belanja anda sudah ada produk yang sama, setelah dijumlahkan melebihi stok yang tersedia");
            return;
          }
          existingCartItem.quantity += this.quantity;
          try {
            await api.put(`cart/${existingCartItem.id}`, {
              user_id: user_id,
              product: product,
              quantity: existingCartItem.quantity,
            });
            this.$toast.success("Produk berhasil diperbaharui ke keranjang", {
              timeout: 2000,
            });
          } catch (error) {
            console.log(error);
          }
        } else {
          try {
            await api.post("cart", {
              user_id: user_id,
              product: product,
              quantity: parseInt(this.quantity),
            });
            this.$toast.success("Produk berhasil dimasukkan ke keranjang", {
              timeout: 2000,
            });
            setTimeout(() => {
              this.$toast.dismiss();
              EventBus.$emit("cartUpdated");
            }, 2000);
          } catch (error) {
            console.log(error);
          }
        }
      } catch (error) {
        console.log(error);
      }
    },

    async addToWishlist(product) {
      try {
        const userInfo = sessionStorage.getItem("trash");
        // const decoded = jwt_decode(userInfo);
        if (!userInfo) {
          this.$toast.info("Anda harus login dulu");
          setTimeout(() => {
            this.$toast.dismiss();
            router.push("/login");
          }, 2000);
          return;
        }
        const user_id = 1;

        const response = await api.get(`wishlist?user_id=${user_id}`);
        const wishlistData = response.data;
        const existingProduct = wishlistData.find((wishlistItem) => wishlistItem.product.id === product.id);
        if (existingProduct) {
          this.$toast.info("Produk sudah ada di wishlist", {
            timeout: 2000,
          });
          return;
        }

        const response2 = await api.post("wishlist", {
          user_id: user_id,
          product,
        });
        this.wishlist.push(response2.data);
        this.$toast.success("Produk berhasil dimasukkan ke wishlist", {
          timeout: 2000,
        });
        setTimeout(() => {
          this.$toast.dismiss();
          EventBus.$emit("wishlistUpdated");
        }, 2000);
      } catch (error) {
        console.error(error);
        this.$toast.error("Terjadi kesalahan saat menambahkan produk ke wishlist");
      }
    },
  },
};
</script>

<style></style>
