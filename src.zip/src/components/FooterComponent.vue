<template>
  <footer class="mt-auto">
    <section class="footer">
      <div class="container">
        <div class="row content-footer">
          <div class="col-md-4">
            <div class="logo">
              <img src="../assets/img/logoblack.png" alt="" />
            </div>
            <div class="contact mt-4" v-if="sosmed">
              <div class="row">
                <div class="col-2">
                  <font-awesome-icon icon="fa-solid fa-phone" />
                </div>
                <div class="col-10">
                  <span>0{{ sosmed.whatsapp }}</span>
                </div>
              </div>
              <div class="row">
                <div class="col-2">
                  <font-awesome-icon icon="fa-solid fa-location-dot" />
                </div>
                <div class="col-9">
                  <span>Jl. Ipik Gandamanah No.303/15, Ciseureuh, Kec. Purwakarta, Kabupaten Purwakarta, Jawa Barat 41118</span>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-2">
            <div class="information mt-3">
              <div class="title-info">
                <p>Menu</p>
              </div>
              <div class="content-info">
                <p><router-link to="/">Home</router-link></p>
                <p><router-link to="/product">Produk</router-link></p>
                <p><router-link to="/cart">Keranjang</router-link></p>
                <p><router-link to="/wishlist">Wishlist</router-link></p>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="pembayaran mt-3">
              <div class="title-bayar">
                <p>Pembayaran</p>
              </div>
              <div class="content-bayar">
                <img src="../assets/img/bayar1.png" alt="" />
                <img src="../assets/img/bayar2.png" alt="" />
                <img src="../assets/img/bayar3.png" alt="" />
                <img src="../assets/img/bayar4.png" alt="" />
                <img src="../assets/img/bayar5.png" alt="" />
                <img src="../assets/img/bayar6.png" alt="" />
                <img src="../assets/img/bayar7.png" alt="" />
                <img src="../assets/img/bayar8.png" alt="" />
                <img src="../assets/img/bayar9.png" alt="" />
                <img src="../assets/img/bayar10.png" alt="" />
                <img src="../assets/img/bayar11.png" alt="" />
                <img src="../assets/img/bayar12.png" alt="" />
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="pembayaran mt-3">
              <div class="title-bayar">
                <p>Pengiriman</p>
              </div>
              <div class="content-bayar">
                <img src="../assets/img/kirim5.png" alt="" />
                <img src="../assets/img/kirim8.png" alt="" />
                <img src="../assets/img/kirim9.png" alt="" />
              </div>
            </div>
          </div>
        </div>
        <div class="cta">
          <div class="img" v-if="sosmed">
            <a v-if="sosmed.facebook" :href="sosmed.facebook" target="_blank"><img src="../assets/img/fb.png" alt="" /></a>
            <a v-if="sosmed.instagram" :href="sosmed.instagram" target="_blank"><img src="../assets/img/ig.png" alt="" /></a>
            <a v-if="sosmed.whatsapp" :href="`https://api.whatsapp.com/send?phone=62${sosmed.whatsapp}`" target="_blank"><img src="../assets/img/wa.png" alt="" /></a>
          </div>
          <div class="cr">Gadgetshop Copyright © 2022 All rights reserved.</div>
        </div>
      </div>
    </section>
  </footer>
</template>

<script>
import apis from "@/apis";
export default {
  name: "FooterComponent",
  data() {
    return {
      sosmed: null,
    };
  },
  async mounted() {
    try {
      const response = await apis.apis.post(apis.PublicPath + "/sosmed");
      this.sosmed = response.data[0];
    } catch (error) {
      console.error(error);
    }
  },
};
</script>
<style></style>
