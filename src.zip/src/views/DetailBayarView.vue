<template>
  <div class="checkout">
    <navbar-component />
    <section class="content-page-kirim">
      <div class="container">
        <div class="content-kirim cek-out">
          <h5 class="title">PEMBAYARAN</h5>
          <div class="row">
            <div class="col-md-7">
              <div class="bg-alamat-kirim" v-if="pengirimDropship">
                <div class="header">Alamat Pengirim</div>
                <div class="content">
                  <p class="name">{{ pengirimDropship.nama }} {{ pengirimDropship.telepon }}</p>
                  <p>{{ pengirimDropship.alamat }}</p>
                </div>
              </div>
              <div class="bg-detail-pesanan" v-if="alamatPengiriman">
                <div class="header">Alamat Pengiriman</div>
                <div class="content">
                  <p class="name">{{ alamatPengiriman.nama_penerima }} ({{ alamatPengiriman.nama_alamat }})</p>
                  <p>{{ alamatPengiriman.telepon }}</p>
                  <p>{{ alamatPengiriman.alamat_lengkap }}, {{ alamatPengiriman.kabupaten }}, {{ alamatPengiriman.provinsi }}</p>
                  <p>{{ alamatPengiriman.kode_pos }}</p>
                </div>
              </div>
              <div class="bg-detail-pesanan abc">
                <div class="header">Produk Dipesan</div>
                <div class="content" v-for="item in checkedOutItems" :key="item.id">
                  <div class="row">
                    <div class="col-md-2 col-3">
                      <img :src="`../assets/img/${item.product.image}`" alt="" />
                    </div>
                    <div class="col-md-10 col-8">
                      <div class="content-pesanan-detail">
                        <p class="title-produk">{{ item.product.namaProduk }}</p>
                        <p class="total-harga">{{ item.product.harga.toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }} x {{ item.quantity }}</p>
                        <p class="total-harga-produk">{{ (item.product.harga * item.quantity).toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-5">
              <div class="bg-detail-shop">
                <div class="header">Ringkasan Belanja</div>
                <div class="detail-total">
                  <div class="total">
                    <span class="total">Harga</span>
                    <span class="harga">{{ totalHarga }}</span>
                  </div>
                  <div class="total">
                    <span class="total"
                      >Ongkir <span class="fw-bold ms-2"> {{ courier }} </span> ({{ cost.description }})</span
                    >
                    <span class="harga">{{ cost.cost && cost.cost.length ? cost.cost[0].value.toLocaleString("id-ID", { style: "currency", currency: "IDR" }) : "" }}</span>
                  </div>
                </div>
                <div class="total sub">
                  <span class="total">Total Harga</span>
                  <span class="harga">{{ (totalHargaNumeric + ongkirNumeric).toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }}</span>
                </div>
                <div class="btn-detail-bayar">
                  <button class="btn btn-outline-success" @click="sosmed" v-bind:href="whatsappURL" target="_blank">Continue WhatsApp</button>
                  <button type="submit" @click="submitForm" class="btn btn-success">Bayar menggunakan midtrans</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import axios from "axios";
import { EventBus } from "@/event-bus";
import shortid from "shortid";
import NavbarComponent from "@/components/NavbarComponent.vue";
import api from "@/api";
import apis from "@/apis";
export default {
  components: { NavbarComponent },
  metaInfo() {
    return {
      title: "Checkout",
    };
  },
  data() {
    return {
      checkedOutItems: [],
      alamatPengiriman: {},
      pengirimDropship: {},
      courier: [],
      cost: [],
      addToCartClicked: false,
    };
  },
  mounted() {
    const storedItems = JSON.parse(sessionStorage.getItem("checkedOutItems"));
    const data = JSON.parse(sessionStorage.getItem("setAlamat"));
    const couriers = JSON.parse(sessionStorage.getItem("courier"));
    const cost = JSON.parse(sessionStorage.getItem("cost"));
    const orderId = JSON.parse(sessionStorage.getItem("order_id"));

    if (storedItems) {
      this.checkedOutItems = storedItems;
    }
    if (couriers) {
      this.courier = String(couriers);
    }
    if (cost) {
      this.cost = cost;
    }
    if (data) {
      this.alamatPengiriman = data.alamat_pengiriman;
      this.pengirimDropship = data.pengirim_dropship;
    }
    if (orderId) {
      this.orderId = orderId;
      console.log(this.orderId);
    }
  },
  created() {
    if (!sessionStorage.getItem("courier") && !sessionStorage.getItem("cost")) {
      this.$router.push("/cart");
      this.$toast.info("Silahkan pilih produk anda di keranjang untuk checkout", {
        timeout: 2000,
      });
    }
    var script = document.createElement("script");
    script.src = "https://app.sandbox.midtrans.com/snap/snap.js";
    script.setAttribute("data-client-key", "SB-Mid-client-61XuGAwQ8Bj8LxSS");
    script.async = true;
    document.head.appendChild(script);
  },
  computed: {
    totalHarga() {
      let total = 0;
      this.checkedOutItems.forEach((item) => {
        total += item.product.harga * item.quantity;
      });
      return total.toLocaleString("id-ID", { style: "currency", currency: "IDR" });
    },
    ongkirNumeric() {
      if (this.cost.cost && this.cost.cost.length > 0) {
        return this.cost.cost[0].value;
      }
      return "";
    },
    totalHargaNumeric() {
      let total = 0;
      this.checkedOutItems.forEach((item) => {
        total += item.product.harga * item.quantity;
      });
      return total;
    },
  },
  methods: {
    async sosmed() {
      try {
        const response = await apis.apis.post(apis.PublicPath + "/sosmed");
        this.sosmed = response.data[0];
        const whatsappURL = this.whatsappURL();
        window.open(whatsappURL, "_blank");
      } catch (error) {
        console.error(error);
      }
    },
    whatsappURL() {
      var message = "Halo, saya ingin memesan produk berikut:%0A%0A";
      message += "%0AOrder ID: TRX-" + this.orderId + "%0A";
      for (var i = 0; i < this.checkedOutItems.length; i++) {
        var item = this.checkedOutItems[i];
        message += `Nama Produk: ${item.product.namaProduk}%0A`;
        message += `Harga: ${item.product.harga.toLocaleString("id-ID", { style: "currency", currency: "IDR" })}%0A`;
        message += `Jumlah: ${item.quantity}%0A`;
        message += `Total Harga: ${(item.product.harga * item.quantity).toLocaleString("id-ID", { style: "currency", currency: "IDR" })}%0A%0A`;
      }
      message += "%0AKurir: " + this.courier + " (Ongkir: " + (this.cost.cost && this.cost.cost.length ? this.cost.cost[0].value.toLocaleString("id-ID", { style: "currency", currency: "IDR" }) : "") + ")";
      if (this.pengirimDropship) {
        message += "%0APengirim: " + this.pengirimDropship.nama + " (" + this.pengirimDropship.telepon + ") " + this.pengirimDropship.alamat;
      }
      message += "%0APenerima: " + this.alamatPengiriman.nama_penerima + " (" + this.alamatPengiriman.telepon + ") " + this.alamatPengiriman.alamat_lengkap + " " + this.alamatPengiriman.kabupaten + " " + this.alamatPengiriman.provinsi;
      message += "%0ATotal Harga: " + Number(this.totalHargaNumeric + this.ongkirNumeric);
      if (this.sosmed && this.sosmed.whatsapp) {
        return "https://api.whatsapp.com/send?phone=62" + this.sosmed.whatsapp + "&text=" + message;
      } else {
        return "";
      }
    },
    async submitForm() {
      try {
        const response = await axios.post("http://localhost:3000/transaction", {
          orderId: this.orderId,
          grossAmount: this.totalHargaNumeric + this.ongkirNumeric,
          nama: this.alamatPengiriman.nama_penerima,
          telepon: this.alamatPengiriman.telepon,
          citi: this.alamatPengiriman.alamat_lengkap,
          prov: this.alamatPengiriman.kabupaten,
          pos: this.alamatPengiriman.kode_pos,
        });

        console.log(response.data);

        window.snap.pay(response.data.token, {
          onSuccess: function (result) {
            console.log("success");
            console.log(result);
          },
          onPending: function (result) {
            console.log("pending");
            console.log(result);
          },
          onError: function (result) {
            console.log("error");
            console.log(result);
          },
          onClose: function () {
            console.log("customer closed the popup without finishing the payment");
          },
        });
      } catch (error) {
        console.error("Error sending data to API:", error);
        alert("Failed to create transaction");
      }
    },

    async sendDataToApi() {
      if (this.addToCartClicked) {
        return;
      }

      this.addToCartClicked = true;
      const transactionId = shortid.generate().toUpperCase();
      // const userInfo = JSON.parse(sessionStorage.getItem("userInfo"));
      const payload = {
        id_transaksi: transactionId,
        user_id: 1,
        courier: this.courier,
        cost: this.cost,
        alamatPengiriman: this.alamatPengiriman,
        pengirimDropship: this.pengirimDropship,
        checkedOutItems: this.checkedOutItems,
        totalHarga: this.totalHargaNumeric + this.ongkirNumeric,
      };

      try {
        const response = await api.post("checkout", payload);
        response.data;
        for (const item of payload.checkedOutItems) {
          const product_id = item.id;
          const product_ids = item.product.id;
          const quantity = item.quantity;
          const sold = item.product.sold;

          await api.delete(`cart/${product_id}`);

          const response = await api.get(`produk/${product_ids}`);
          const product = response.data;
          product.stok -= quantity;
          product.sold = sold + quantity;
          await api.put(`produk/${product_ids}`, product);
        }

        this.$toast.success("Silahkan lakukan pembayaran", {
          timeout: 2000,
        });
        setTimeout(() => {
          this.$toast.dismiss();
          EventBus.$emit("orderUpdated");
          sessionStorage.removeItem("checkedOutItems");
          sessionStorage.removeItem("setAlamat");
          sessionStorage.removeItem("courier");
          sessionStorage.removeItem("cost");
          this.$router.push("/bayar");
        }, 2000);
      } catch (error) {
        console.error("Error sending data to API:", error);
      }
    },
  },
};
</script>
