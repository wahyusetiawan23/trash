<template>
  <div>
    <h1>Callback</h1>
    <p>Order ID: {{ orderId }}</p>
    <p>Transaction Status: {{ transactionStatus }}</p>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "CallbackView",
  data() {
    return {
      orderId: "",
      transactionStatus: "",
    };
  },
  mounted() {
    axios
      .post("http://localhost:3000/callback", { order_id: "ORDER-1681800240671", transaction_status: "settlement" })
      .then((response) => {
        this.orderId = response.data.order_id;
        this.transactionStatus = response.data.transaction_status;
        console.log(response);
      })
      .catch((error) => {
        console.log(error);
      });
  },
};
</script>
