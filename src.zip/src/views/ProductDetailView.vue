<template>
  <div class="detail">
    <navbar-component />
    <section class="content-details">
      <div class="container">
        <div class="details-page">
          <h5 class="judul-detail">DETAIL PRODUK</h5>
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><router-link to="/product">Produk</router-link></li>
              <li class="breadcrumb-item" aria-current="page">{{ $route.name }}</li>
            </ol>
          </nav>
          <div class="content-page-details">
            <div class="row">
              <div class="col-md-5 text-center">
                <img :src="bigImage" class="big" alt="" />
                <div class="row thumbnail">
                  <div v-for="(foto, index) in fotos" :key="index" class="col-md-3">
                    <img v-if="foto !== 'img_produk.png'" :src="`${BASE_URL}/produk/${foto}`" class="thumb" alt="" @click="changeBigImage(index)" />
                  </div>
                </div>
              </div>
              <div class="col-md-7">
                <div class="title">
                  <p>{{ product.nama_produk }}</p>
                </div>
                <div class="rating">
                  <span><font-awesome-icon icon="fa-solid fa-star" class="me-2" />{{ product.grade }}</span>

                  <span>|</span>
                  <span>{{ product.terjual }} Terjual</span>
                </div>
                <div class="harga">
                  <div class="c-harga d-flex align-items-center">
                    <div class="r-harga">{{ product.harga_jual ? (product.harga_jual * quantity).toLocaleString("id-ID", { style: "currency", currency: "IDR" }) : "" }}</div>
                  </div>
                </div>
                <div class="form-detail">
                  <table class="table table-borderless">
                    <tbody>
                      <tr>
                        <th>Berat</th>
                        <td>{{ product.berat }} gram</td>
                      </tr>
                      <tr>
                        <th>Stok</th>
                        <td>{{ product.stok }}</td>
                      </tr>
                      <tr>
                        <th>Kuantitas</th>
                        <td class="d-flex">
                          <div class="btn-group btn-group-sm" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-success minus" @click="decreaseQuantity">
                              <font-awesome-icon icon="fa-solid fa-minus" />
                            </button>
                            <input class="form-control quantity" v-model.number="quantity" />
                            <button type="button" class="btn btn-success plus" @click="increaseQuantity">
                              <font-awesome-icon icon="fa-solid fa-plus" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <div class="btn-details">
                    <div class="row">
                      <div class="col-md-6">
                        <button href="#" class="btn btn-outline-success add-to-wishlist" @click="addToWishlist(product)"><font-awesome-icon icon="fa-solid fa-heart" class="me-2" />Masukkan Whislist</button>
                      </div>
                      <div class="col-md-6">
                        <button href="#" class="btn btn-success add-to-cart-button disabled" v-if="product.stok == 0"><font-awesome-icon icon="fa-solid fa-cart-plus" class="me-2" />STOK HABIS</button>
                        <button href="#" class="btn btn-success add-to-cart-button" v-else @click="addToCart(product)"><font-awesome-icon icon="fa-solid fa-cart-plus" class="me-2" />Masukkan Keranjang</button>
                      </div>
                    </div>
                  </div>
                  <div class="content-desc-details">
                    <div class="bg-desc-details">
                      <span>Deskripsi Produk</span>
                    </div>
                    <div class="content" v-if="product.deskripsi == null">Tidak ada deskripsi</div>

                    <div class="content" :style="{ '-webkit-line-clamp': isCollapsed ? 'unset' : '17', '-webkit-box-orient': isCollapsed ? 'unset' : 'vertical' }" v-html="formattedString" v-else></div>
                    <a v-if="product.deskripsi != null" href="#" @click="toggleCollapse" class="detail-show">{{ isCollapsed ? "Sembunyikan" : "Lihat Selengkapnya.." }}</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="btn-more-view d-flex justify-content-end mt-3 mb-3">
            <router-link to="/product" class="btn btn-warning">Produk Lainnya <font-awesome-icon :icon="['fas', 'arrow-right']" beat-fade class="ms-2" /></router-link>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
// @ is an alias to /src
import { BASE_URL } from "@/config";
import apis from "@/apis";
import api from "@/api";
import router from "@/router";
import NavbarComponent from "@/components/NavbarComponent.vue";
import { EventBus } from "@/event-bus.js";
export default {
  components: { NavbarComponent },
  name: "ProductDetailView",
  metaInfo() {
    return {
      title: "Detail produk Gadgetcare",
    };
  },

  data() {
    return {
      maxLength: 200,
      showMore: false,
      product: {},
      bigImage: "",
      quantity: 1,
      BASE_URL,
      fotos: [],
      myString: "",
      isCollapsed: false,
    };
  },
  computed: {
    formattedString() {
      return this.myString.replace(/\n/g, "<br>");
    },
  },
  async created() {
    try {
      const id = this.$route.params.id;
      let data = {
        produk: id,
      };
      const response = await apis.apis.post(apis.PublicPath + "/detail_produk", data, {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
      });
      this.product = response.data;
      this.myString = response.data.deskripsi;
      this.fotos = [this.product.foto_1, this.product.foto_2, this.product.foto_3, this.product.foto_4];
      this.bigImage = `${BASE_URL}produk/${this.product.foto_1}`;
      this.quantity = 1;
    } catch (error) {
      console.log(error);
    }
  },

  methods: {
    toggleCollapse() {
      this.isCollapsed = !this.isCollapsed;
    },
    changeBigImage(index) {
      this.bigImage = `${BASE_URL}/produk/${this.fotos[index]}`;
    },
    increaseQuantity() {
      if (this.quantity < this.product.stok) {
        this.quantity++;
      }
    },
    decreaseQuantity() {
      if (this.quantity > 1) {
        this.quantity--;
      }
    },
    async addToCart(product) {
      if (!sessionStorage.getItem("userInfo")) {
        this.$toast.error("Anda harus login terlebih dahulu");
        router.push("/login");
        return;
      }

      if (isNaN(this.quantity) || this.quantity <= 0) {
        this.$toast.error("Jumlah kuantitas produk minimal 1", {
          timeout: 2000,
        });
        setTimeout(() => {
          this.$toast.dismiss();
          this.quantity = 1;
        }, 2000);
        return;
      }

      const userInfo = JSON.parse(sessionStorage.getItem("userInfo"));
      const user_id = userInfo[0].id;

      try {
        const response = await api.get(`cart?user_id=${user_id}`);
        const cart = response.data;
        if (this.quantity > parseInt(product.stok)) {
          this.$toast.error("Jumlah produk yang diminta melebihi stok yang tersedia", {
            timeout: 2000,
          });
          setTimeout(() => {
            this.$toast.dismiss();
            this.quantity = 1;
          }, 2000);
          return;
        }

        const existingCartItem = cart.find((i) => i.product.id === product.id);
        if (existingCartItem) {
          const totalQuantity = existingCartItem.quantity + parseInt(this.quantity);
          if (totalQuantity > existingCartItem.product.stok) {
            this.$toast.error("Dikeranjang belanja anda sudah ada produk yang sama, setelah dijumlahkan melebihi stok yang tersedia", {
              timeout: 2000,
            });
            setTimeout(() => {
              this.$toast.dismiss();
              this.quantity = 1;
            }, 2000);
            return;
          }
          existingCartItem.quantity += this.quantity;

          await api.put(`cart/${existingCartItem.id}`, {
            user_id: user_id,
            product: product,
            quantity: existingCartItem.quantity,
          });

          this.$toast.success("Produk berhasil diperbaharui di keranjang", {
            timeout: 2000,
          });
        } else {
          await api.post("cart", {
            user_id: user_id,
            product: product,
            quantity: parseInt(this.quantity),
          });

          this.$toast.success("Produk berhasil dimasukkan ke keranjang", {
            timeout: 2000,
          });

          setTimeout(() => {
            this.$toast.dismiss();
            EventBus.$emit("cartUpdated");
          }, 2000);
        }
      } catch (error) {
        console.log(error);
      }
    },

    async addToWishlist(product) {
      try {
        const userInfo = JSON.parse(sessionStorage.getItem("userInfo"));
        if (!userInfo) {
          this.$toast.info("Anda harus login dulu");
          setTimeout(() => {
            this.$toast.dismiss();
            router.push("/login");
          }, 2000);
          return;
        }
        const user_id = userInfo[0].id;
        const response = await api.get(`wishlist?user_id=${user_id}`);
        const wishlistData = response.data;
        const existingProduct = wishlistData.find((wishlistItem) => wishlistItem.product.id === product.id);
        if (existingProduct) {
          this.$toast.info("Produk sudah ada di wishlist", {
            timeout: 2000,
          });
          return;
        }
        const response2 = await api.post("wishlist", {
          user_id: user_id,
          product,
        });
        this.wishlist.push(response2.data);
        this.$toast.success("Produk berhasil dimasukkan ke wishlist", {
          timeout: 2000,
        });
        setTimeout(() => {
          this.$toast.dismiss();
          EventBus.$emit("wishlistUpdated");
        }, 2000);
      } catch (error) {
        console.error(error);
        this.$toast.error("Terjadi kesalahan saat menambahkan produk ke wishlist");
      }
    },
  },
};
</script>
<style></style>
