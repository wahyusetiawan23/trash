const express = require("express");
const cors = require("cors");
const midtransClient = require("midtrans-client");

const app = express();
const port = 3000;

const snap = new midtransClient.Snap({
  isProduction: false,
  serverKey: "SB-Mid-server-GqiPUxyw2WnOuYI5XuxQvX-d",
  clientKey: "SB-Mid-client-utWahh74-ME7xS5k",
});
app.use(cors());
app.use(express.json());

app.post("/transaction", (req, res) => {
  const { grossAmount, nama, telepon, citi, prov, pos } = req.body;
  // if (!items || !Array.isArray(items)) {
  //   return res.status(400).send({ message: "Invalid items" });
  // }
  // const itemDetails = items.map((item) => {
  //   // const quantity = parseInt(item.nominal);
  //   const price = parseInt(item.amount);
  //   return {
  //     id: item.id,
  //     price: price,
  //     // quantity: quantity,
  //     name: item.description,
  //     brand: "Midtrans",
  //     category: "Payment",
  //     merchant_name: "Midtrans",
  //   };
  // });
  // const grossAmount = items.reduce((total, item) => total + item.amount, 0);
  const transactionDetails = {
    order_id: `ORDER-${Date.now()}`,
    gross_amount: grossAmount,
    currency: "IDR",
    transaction_details: {
      order_id: `ORDER-${Date.now()}`,
      gross_amount: grossAmount,
    },
    // item_details: itemDetails,
    customer_details: {
      first_name: nama,
      phone: telepon,
      email: "test@midtrans.com",
      address: citi,
      shipping_address: {
        first_name: nama,
        phone: telepon,
        address: citi,
        city: prov,
        postal_code: pos,
        country_code: "IDN",
      },
    },
  };

  snap
    .createTransaction(transactionDetails)
    .then((transaction) => {
      res.send({ token: transaction.token });
    })
    .catch((error) => {
      console.log(error);
      res.status(500).send({ message: "Failed to create transaction" });
    });
});

app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
