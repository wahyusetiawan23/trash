<template>
  <div>
    <h1>Payment Result:</h1>
    <p>{{ paymentResult }}</p>
  </div>
</template>

<script>
export default {
  data() {
    return {
      paymentResult: null,
    };
  },
  mounted() {
    window.addEventListener("message", this.handleMessage);
  },
  beforeDestroy() {
    window.removeEventListener("message", this.handleMessage);
  },
  methods: {
    handleMessage(event) {
      if (event.origin !== "https://app.midtrans.com") {
        return;
      }

      const { data } = event;
      if (data.status_code === "200") {
        this.paymentResult = data;
      }
    },
  },
};
</script>
