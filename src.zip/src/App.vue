<template>
  <div id="app" :class="{ fadeOut: refreshing }">
    <!-- <NavbarComponent /> -->
    <router-view />
    <footer-component />
  </div>
</template>

<script>
import FooterComponent from "./components/FooterComponent.vue";
// import NavbarComponent from "./components/NavbarComponent.vue";

export default {
  components: { FooterComponent },
  name: "App",
  data() {
    return {
      refreshing: false,
    };
  },
  mounted() {
    window.addEventListener("beforeunload", () => {
      this.refreshing = true;
    });
  },
};
</script>

<style>
.fadeOut {
  animation: 0.5s ease;
}
</style>
<head>
  <title>{{ $metaInfo.title }}</title>
</head>
