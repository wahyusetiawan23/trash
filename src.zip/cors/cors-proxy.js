var cors_proxy = require("cors-anywhere");

const host = "0.0.0.0";
const port = 8080;

cors_proxy
  .createServer({
    originWhitelist: [],
    requireHeader: [],
    removeHeaders: ["cookie", "cookie2"],
    setHeaders: {
      "Access-Control-Allow-Origin": "http://localhost:8080",
    },
  })
  .listen(port, host, () => {
    console.log(`Cors Anywhere server berjalan di http://${host}:${port}`);
  });
