<template>
  <div class="cart">
    <NavbarComponent />
    <section class="content-keranjang">
      <div class="container">
        <h5 class="title-cart">KERANJANG</h5>
        <div v-if="cartItems.length === 0">
          <div class="empty-wishlist">
            <div class="row">
              <div class="col-md-3">
                <img src="../assets/img/empty.png" alt="" />
              </div>
            </div>
          </div>
          <div class="empty-wishliss mt-3 text-center">
            <router-link to="/product"> <button class="btn btn-wishliss btn-success">Mulai berbelanja</button> </router-link>
          </div>
        </div>

        <div v-else class="row content-page-keranjang">
          <div class="col-md-8">
            <div class="header-keranjang">
              <span> <input class="form-check-input" v-model="selectAllItemsSelected" type="checkbox" name="all" @change="toggleAllItemsSelected" /><span class="px-2">Pilih Semua</span></span>
              <a class="btn btn-sm btn-primary" id="btn-hapus" v-if="selectAllItemsSelected" @click="deleteAllProducts(item)"> <font-awesome-icon icon="fa-solid fa-trash-can" />Hapus </a>
            </div>
            <div class="list-keranjang">
              <div class="item-cart" v-for="item in reversedCartList" :key="item.id">
                <div class="row list-item-cart mb-3">
                  <div class="col-md-1">
                    <input class="form-check-input checkSingle" type="checkbox" :value="item" v-model="itemSelected" />
                  </div>
                  <div class="col-md-2 col-6">
                    <img :src="`../assets/img/${item.product.image}`" alt="" />
                  </div>
                  <div class="col-md-5 col-6">
                    <span class="badge text-bg-danger" v-if="item.product.stok == 0"><font-awesome-icon :icon="['fas', 'circle-info']" beat-fade style="color: #ffffff" class="me-1" /> STOK HABIS</span>
                    <p class="namaProduk">{{ item.product.namaProduk }}</p>
                    <p class="pcs">Harga /pcs :{{ item.product.harga.toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }}</p>
                    <p class="note">Stok :{{ item.product.stok }}</p>
                    <p class="note">Berat :{{ item.product.berat * item.quantity }} gram</p>
                  </div>
                  <div class="col-md-4 text-end d-flex justify-content-end align-items-end">
                    <div>
                      <span class="harga">Total :{{ (item.product.harga * item.quantity).toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }}</span>
                      <div>
                        <a class="btn btn-danger btn-sm mt-2 me-2" @click="hapusItemCart(item.id)"><font-awesome-icon icon="fa-solid fa-trash-can" /></a>
                        <div class="btn-group btn-group-sm mt-2" role="group" aria-label="Basic example">
                          <button type="button" class="btn btn-success minus" @click="decreaseQuantity(item)">
                            <font-awesome-icon icon="fa-solid fa-minus" />
                          </button>
                          <input class="form-control quantity" v-model="item.quantity" />
                          <button type="button" class="btn btn-success plus" @click="increaseQuantity(item)">
                            <font-awesome-icon icon="fa-solid fa-plus" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="total-belanja">
              <div class="total-price">
                <span class="title">Total Harga</span>
                <span class="harga">{{ totalPrice.toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }}</span>
              </div>
              <div class="mt-3">
                <a class="btn btn-success" @click="checkout(cartItems)">CHECKOUT</a>
                <router-link to="/product" class="btn btn-outline-success">Lanjut Berbelanja</router-link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
// import jwt_decode from "jwt-decode";
import { EventBus } from "@/event-bus";
import api from "@/api";
import NavbarComponent from "@/components/NavbarComponent.vue";
import Swal from "sweetalert2";
export default {
  name: "CartView",
  components: { NavbarComponent },
  beforeRouteLeave(to, from, next) {
    if (to.path === from.path) {
      next(false);
    } else {
      next();
    }
  },
  metaInfo() {
    return {
      title: "Keranjang anda di Gadgetcare",
    };
  },
  data() {
    return {
      isChecked: false,
      item: [],
      cartItems: [],
      quantity: {},
      itemSelected: [],
      totalPrice: 0,
      selectAllItemsSelected: false,
    };
  },
  computed: {
    reversedCartList() {
      return this.cartItems.slice().reverse();
    },
  },
  created() {
    const token = sessionStorage.getItem("trash");
    const decoded = 1;
    if (token) {
      this.userInfo = decoded;
      api
        .get("cart?user_id=" + decoded)
        .then((response) => {
          this.cartItems = response.data;
        })
        .catch((error) => {
          console.log(error);
        });
    }
  },
  methods: {
    increaseQuantity(item) {
      if (item.quantity < item.product.stok) {
        item.quantity++;
      }
    },
    decreaseQuantity(item) {
      if (item.quantity > 1) {
        item.quantity--;
      }
    },
    updateTotalPrice() {
      this.totalPrice = this.itemSelected.reduce((total, item) => {
        if (this.itemSelected.includes(item)) {
          return total + item.product.harga * item.quantity;
        }
      }, 0);
    },
    toggleAllItemsSelected(event) {
      if (event.target.checked) {
        this.itemSelected = this.cartItems.slice();
        this.selectAllItemsSelected = true;
      } else {
        this.itemSelected = [];
        this.selectAllItemsSelected = false;
      }
      this.updateTotalPrice();
    },
    toggleItemSelected(itemId) {
      const index = this.itemSelected.indexOf(itemId);
      if (index !== -1) {
        this.itemSelected.splice(index, 1);
      } else {
        this.itemSelected.push(itemId);
      }
      this.updateTotalPrice();
    },
    hapusItemCart(id) {
      Swal.fire({
        title: "Apakah Anda yakin?",
        text: "Anda akan menghapus item produk keranjang Anda",
        icon: "warning",
        iconColor: "#bf3c3c",
        color: "#fff",
        background: " #00000080",
        showCancelButton: true,
        confirmButtonColor: "#bf3c3c",
        confirmButtonText: "Ya, hapus!",
        cancelButtonText: "Tidak",
      }).then((result) => {
        if (result.isConfirmed) {
          api
            .delete(`cart/${id}`)
            .then(() => {
              this.$toast.warning("Item produk berhasil dihapus dari keranjang!", {
                timeout: 2000,
              });
              setTimeout(() => {
                const index = this.cartItems.findIndex((item) => item.id === id);
                this.cartItems.splice(index, 1);
                this.$toast.dismiss();
                EventBus.$emit("cartDelete");
              }, 2000);
            })
            .catch((error) => {
              console.log(error);
            });
        }
      });
    },
    async deleteAllProducts() {
      try {
        const result = await Swal.fire({
          title: "Apakah Anda yakin?",
          text: "Anda akan menghapus item produk keranjang Anda",
          icon: "warning",
          iconColor: "#bf3c3c",
          color: "#fff",
          background: " #00000080",
          showCancelButton: true,
          confirmButtonColor: "#bf3c3c",
          confirmButtonText: "Ya, hapus!",
          cancelButtonText: "Tidak",
        });
        if (result.isConfirmed) {
          for (const item of this.cartItems) {
            await api.delete(`cart/${item.id}`);
          }
          this.$toast.warning("Semua item produk berhasil dihapus dari keranjang!", {
            timeout: 2000,
          });
          setTimeout(() => {
            this.$toast.dismiss();
            EventBus.$emit("cartDelete");
            this.cartItems = [];
            this.itemSelected = [];
          }, 2000);
        }
      } catch (error) {
        console.log(error);
      }
    },

    checkout(cartItems) {
      let error = false;
      for (let i = 0; i < this.itemSelected.length; i++) {
        if (isNaN(cartItems[i].quantity) || this.itemSelected[i].quantity <= 0) {
          error = true;
          this.$toast.error("Jumlah kuantitas produk minimal 1", {
            timeout: 2000,
          });
          setTimeout(() => {
            this.$toast.dismiss();
          }, 2000);
          break;
        }
        if (cartItems[i].quantity > this.itemSelected[i].product.stok) {
          error = true;
          this.$toast.error("Jumlah produk yang diminta melebihi stok yang tersedia", {
            timeout: 2000,
          });
          setTimeout(() => {
            this.$toast.dismiss();
          }, 2000);
          break;
        }
      }

      if (!error) {
        if (this.itemSelected.length === 0) {
          Swal.fire({
            icon: "error",
            title: "Oops...",
            color: "#fff",
            text: "Silakan pilih produk yang ingin dibeli",
            confirmButtonColor: "#00985b",
            background: " #00000080",
            width: "24em",
            toast: "true",
            timer: 2000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.addEventListener("mouseenter", Swal.stopTimer);
              toast.addEventListener("mouseleave", Swal.resumeTimer);
            },
          });
          return;
        }
        const selectedItems = [...this.itemSelected];
        const items = selectedItems.map((item) => {
          return {
            user_id: item.user_id,
            product: item.product,
            quantity: item.quantity,
            id: item.id,
          };
        });

        sessionStorage.setItem("checkedOutItems", JSON.stringify(items));
        this.$toast.info("Anda akan dialihkan kehalaman checkout", {
          timeout: 2000,
        });
        setTimeout(() => {
          this.$toast.dismiss();
          if (this.$router.currentRoute.path !== "/checkout") {
            this.$router.push("/checkout");
          }
        }, 2000);
        return;
      }
    },
  },
  watch: {
    itemSelected: {
      handler() {
        this.selectAllItemsSelected = this.itemSelected.length === this.cartItems.length;
        this.updateTotalPrice();
      },
      deep: true,
    },
  },
};
</script>

<style>
.row-containerr {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-gap: 10px;
}
</style>
