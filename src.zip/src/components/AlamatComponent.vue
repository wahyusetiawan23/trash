<template>
  <div class="content-kirim">
    <h5 class="title">PENGIRIMAN DAN PEMBAYARAN</h5>
    <div class="bg-alamat">
      <div class="content">
        <div class="header-alamat">
          <span class="header">Alamat Pengiriman</span>
          <button-add-alamat-component />
        </div>
        <div class="content-data-alamat">
          <div class="bg-cek-alamat" v-for="alamat in reversedAlamatList" :key="alamat.id">
            <div class="form-check">
              <input class="form-check-input" type="radio" name="show" :id="'show' + alamat.id" :value="alamat.id" :checked="isUtama(alamat)" />
              <label class="form-check-label" :for="'show' + alamat.id">
                <p class="name">
                  {{ alamat.nama_penerima }} <span>({{ alamat.telepon }})</span>
                </p>
                <p class="alamat">{{ alamat.alamat_lengkap }}, {{ alamat.kabupaten }}, {{ alamat.provinsi }}</p>
                <p class="alamat">
                  <span>{{ alamat.kode_pos }}</span>
                </p>
              </label>
            </div>
            <div class="edit-alamat">
              <span class="badge text-bg-success" v-if="alamat.utama">Alamat Utama</span>
            </div>
          </div>
        </div>
      </div>
      <div class="dropship">
        <div class="row">
          <div class="col-md-3">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" value="" v-model="showForm" @click="showForm = !showForm" />
              <label class="form-check-label" for="flexCheckDefault"> Kirim Sebagai Dropshiper </label>
            </div>
          </div>
          <div class="col-md-12">
            <div class="form-dropship" v-if="showForm">
              <div class="row">
                <div class="col-md">
                  <input type="text" class="form-control" v-model="namaPengirim" id="exampleFormControlInput1" placeholder="Nama Pengirim" />
                </div>
                <div class="col-md">
                  <input type="text" class="form-control" v-model="noTelepon" id="exampleFormControlInput2" placeholder="No Telepon" />
                </div>
                <div class="col-md">
                  <input type="text" class="form-control" v-model="alamatPengirim" id="exampleFormControlInput3" placeholder="Alamat" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="btn-next">
      <a class="btn btn-outline-success" @click="kirimData()">Selanjutnya <font-awesome-icon icon="fa-solid fa-chevron-right" /></a>
    </div>
  </div>
</template>

<script>
import $ from "jquery";
import api from "@/api";
import { FontAwesomeIcon } from "@fortawesome/vue-fontawesome";
import ButtonAddAlamatComponent from "@/components/ButtonAddAlamatComponent.vue";
export default {
  components: { FontAwesomeIcon, ButtonAddAlamatComponent },
  metaInfo() {
    return {
      title: "Checkout",
    };
  },
  data() {
    return {
      selectedAlamat: null,
      showForm: false,
      type: "password",
      userInfo: "",
      isDataSubmitted: false,
      alamatList: [],
      namaPengirim: "",
      noTelepon: "",
      alamatPengirim: "",
    };
  },
  computed: {
    isUtama() {
      return function (alamat) {
        return alamat.utama === true;
      };
    },
    reversedAlamatList() {
      return this.alamatList.slice().reverse();
    },
  },

  created() {
    // const userInfo = sessionStorage.getItem("token");
    // if (userInfo) {
    //   this.userInfo = userInfo[0];
    api
      .get("alamat_user?user_id=1")
      .then((response) => {
        this.alamatList = response.data;
      })
      .catch((error) => {
        console.log(error);
        alert("Terjadi kesalahan saat mengambil data alamat");
      });
    // }
    if (!sessionStorage.getItem("checkedOutItems")) {
      this.$router.push("/cart");
      this.$toast.info("Silahkan pilih produk anda di keranjang untuk checkout", {
        timeout: 2000,
      });
    }
  },
  methods: {
    kirimData: function () {
      var alamatTerpilih = this.alamatList.find(function (alamat) {
        return alamat.id == $("input[name='show']:checked").val();
      });
      var data = {
        alamat_pengiriman: {
          nama_penerima: alamatTerpilih.nama_penerima,
          nama_alamat: alamatTerpilih.nama_alamat,
          telepon: alamatTerpilih.telepon,
          provinsi: alamatTerpilih.provinsi,
          kabupaten: alamatTerpilih.kabupaten,
          province_id: alamatTerpilih.province_id,
          city_id: alamatTerpilih.city_id,
          alamat_lengkap: alamatTerpilih.alamat_lengkap,
          kode_pos: alamatTerpilih.kode_pos,
        },
      };
      if (this.showForm) {
        data.pengirim_dropship = {
          nama: this.namaPengirim,
          telepon: this.noTelepon,
          alamat: this.alamatPengirim,
        };
      }
      sessionStorage.setItem("setAlamat", JSON.stringify(data));
      this.$toast.info("Anda akan dialihkan kehalaman checkout", {
        timeout: 2000,
      });
      setTimeout(() => {
        this.$toast.dismiss();
        // }
      }, 2000);

      return;
    },
  },
};
</script>
