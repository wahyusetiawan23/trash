const midtransClient = require("midtrans-client");

let snap = new midtransClient.Snap({
  isProduction: true,
  serverKey: "SB-Mid-server-GqiPUxyw2WnOuYI5XuxQvX-d",
  clientKey: "SB-Mid-client-utWahh74-ME7xS5k",
  apiUrl: "/snap/v1/transactions",
});

module.exports = snap;
