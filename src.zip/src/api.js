import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:3004/",
  //   headers: {
  //     "GC-KEY": "123456",
  //     "Content-Type": "application/json",
  //   },
});

export default api;
