<template>
  <div class="kirim">
    <navbar-component />
    <section class="content-page-kirim">
      <div class="container">
        <div class="content-kurir">
          <h5 class="title">PENGIRIMAN DAN PEMBAYARAN</h5>
          <div class="bg-kurir">
            <span class="judul-kirim">Metode Pengiriman</span>
            <form @submit.prevent>
              <div>
                <div
                  v-for="(courier, index) in courierList"
                  :key="index"
                  class="card-radio mt-2"
                  :class="{ selected: courier.code === selectedCourier }"
                  @click="
                    selectedCourier = courier.code;
                    getShippingCost();
                  "
                >
                  <input type="radio" :id="`courier-${index}`" :value="courier.code" v-model="selectedCourier" />
                  <label :for="`courier-${index}`">{{ courier.name }}</label>
                </div>
              </div>
            </form>

            <div v-if="rajaongkir.results && rajaongkir.results.length > 0">
              <div class="card-radio mt-2" v-for="(cost, index) in rajaongkir.results[0].costs" :key="index" :class="{ selected: selectedShippingCost === cost }" @click="selectedShippingCost = cost">
                <input type="radio" :id="`cost-${index}`" :value="cost" v-model="selectedShippingCost" />
                <label :for="`cost-${index}`">
                  <p>{{ cost.service }}</p>
                  {{ cost.cost[0].value.toLocaleString("id-ID", { style: "currency", currency: "IDR" }) }} ({{ cost.cost[0].etd }} hari)</label
                >
              </div>
            </div>
            <div v-else>
              <p>Loading...</p>
            </div>
          </div>
          <div class="btn-next">
            <a @click="onNextClicked()" class="btn btn-outline-success" :class="{ disabled: !selectedShippingCost }" :disabled="!selectedShippingCost">Selanjutnya <font-awesome-icon icon="fa-solid fa-chevron-right" /></a>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import axios from "axios";
import NavbarComponent from "@/components/NavbarComponent.vue";

export default {
  components: { NavbarComponent },
  data() {
    return {
      cost: "",
      rajaongkir: {},
      apiKey: "4352909653b2b207507bad78b987761b",
      selectedCourier: "jne",
      courierList: [
        { code: "jne", name: "JNE" },
        { code: "pos", name: "POS" },
        { code: "tiki", name: "TIKI" },
      ],
      selectedShippingCost: null,
    };
  },
  created() {
    if (!sessionStorage.getItem("setAlamat")) {
      this.$router.push("/cart");
      this.$toast.info("Silahkan pilih produk anda di keranjang untuk checkout", {
        timeout: 2000,
      });
    }
  },
  mounted() {
    this.getShippingCost();
  },
  methods: {
    async getShippingCost() {
      const checkedOutItems = JSON.parse(sessionStorage.getItem("checkedOutItems"));
      const totalWeight = checkedOutItems.reduce((acc, item) => {
        const productWeight = item.product.berat * item.quantity;
        return acc + productWeight;
      }, 0);
      const alamat = JSON.parse(sessionStorage.getItem("setAlamat"));
      const cityId = alamat.alamat_pengiriman.city_id;
      try {
        const response = await axios.post(
          "http://localhost:8080/https://api.rajaongkir.com/starter/cost",
          {
            origin: "376",
            destination: cityId,
            weight: totalWeight,
            courier: this.selectedCourier,
          },
          {
            headers: {
              key: this.apiKey,
              "Content-Type": "application/x-www-form-urlencoded",
            },
          }
        );
        this.rajaongkir = response.data.rajaongkir;
      } catch (error) {
        console.error(error);
      }
    },
    onNextClicked() {
      sessionStorage.setItem("courier", JSON.stringify(this.selectedCourier));
      sessionStorage.setItem("cost", JSON.stringify(this.selectedShippingCost));
      this.$toast.info("Anda akan dialihkan kehalaman detail checkout", {
        timeout: 1500,
      });
      setTimeout(() => {
        this.$toast.dismiss();
        if (this.$router.currentRoute.path !== "/detail-bayar") {
          this.$router.push("/detail-bayar");
        }
      }, 1500);
    },
  },
};
</script>
<style>
select {
  display: none;
}

.card-radio {
  display: inline-block;
  margin-right: 10px;
  margin-bottom: 10px;
  padding: 10px 20px;
  border: 1px solid #ccc;
  border-radius: 4px;
  cursor: pointer;
  text-align: center;
}

.card-radio p {
  margin-bottom: 5px;
}

.card-radio.selected {
  color: #000 !important;
  background: #00985b;
}

.card-radio:hover {
  background-color: #f7f7f7;
}

.card-radio label {
  display: block;
  font-weight: bold;
}

.card-radio input {
  display: none;
}

.card-radio input:checked + label {
  color: #fff;
}

.card-radio input:checked + label:before {
  color: #00985b;
  margin-right: 5px;
}
</style>
