<template>
  <div class="akun">
    <navbar-component />
    <section class="content-page-akun">
      <div class="container">
        <div class="content-akun">
          <h5 class="title">AKUN SAYA</h5>
          <div class="row">
            <div class="col-md-3">
              <MenuAkunComponent />
            </div>
            <div class="col-md-9">
              <div class="card-content-profil">
                <div class="header-profil">Ubah Password</div>
                <div class="content-profil">
                  <form @submit.prevent="updateProfile">
                    <div class="card-body">
                      <div class="form-group row mb-3">
                        <label for="lama" class="col-sm-3 col-form-label">Password Lama</label>
                        <div class="col-sm-9">
                          <div class="input-group">
                            <input :type="type" class="form-control" id="lama" v-model="password" placeholder="*********" />
                            <span class="input-group-text" id="basic-addon1">
                              <a href="#" title="show password" data-bs-toggle="tooltip" @click="showPassword()">
                                <font-awesome-icon icon="fa-solid fa-eye-slash" />
                              </a>
                            </span>
                          </div>
                        </div>
                      </div>
                      <div class="form-group row mb-3">
                        <label for="baru" class="col-sm-3 col-form-label">Password Baru</label>
                        <div class="col-sm-9">
                          <div class="input-group">
                            <input :type="types" class="form-control" id="baru" v-model="password2" placeholder="*********" />
                            <span class="input-group-text" id="basic-addon2">
                              <a href="#" title="show password" data-bs-toggle="tooltip" @click="showPassword2()">
                                <font-awesome-icon icon="fa-solid fa-eye-slash" />
                              </a>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="btn-profil">
                      <button type="submit" class="btn btn-success">Update Password</button>
                    </div>
                  </form>
                  <button type="submit" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#editPassword">Lupa Password?</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="modal fade modal-alamat" id="editPassword" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Lupa Password Anda?</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p class="text-center mb-2">Link untuk reset password akan kami kirimkan ke email Anda</p>
            <div class="mb-2">
              <input type="email" class="form-control" placeholder="Email akun anda" id="email" />
            </div>
            <div class="btn-modal-password">
              <a href="" class="btn btn-danger">Reset Password</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MenuAkunComponent from "@/components/MenuAkunComponent.vue";
import NavbarComponent from "@/components/NavbarComponent.vue";
import apis from "@/apis";
export default {
  components: { MenuAkunComponent, NavbarComponent },
  metaInfo() {
    return {
      title: "Profil anda di Gadgetcare",
    };
  },
  data() {
    return {
      type: "password",
      types: "password",
      data: "",
      password: "",
      password2: "",
    };
  },
  mounted() {
    const token = sessionStorage.getItem("token");

    if (token) {
      apis.apis
        .post(apis.ContentPath + "/userAccount", null, {
          headers: {
            Authorization: "Bearer " + token,
          },
        })
        .then((response) => {
          this.data = response.data;
        })
        .catch((error) => {
          console.log(error);
        });
    } else {
      console.log();
    }
  },
  methods: {
    showPassword() {
      if (this.type === "password") {
        this.type = "text";
      } else {
        this.type = "password";
      }
    },
    showPassword2() {
      if (this.types === "password") {
        this.types = "text";
      } else {
        this.types = "password";
      }
    },
  },
};
</script>
