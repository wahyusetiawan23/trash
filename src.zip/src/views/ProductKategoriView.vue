<template>
  <div class="product-kategori">
    <navbar-component />
    <section class="content-product">
      <div class="container">
        <div class="product-page">
          <h5 class="judul-page">PRODUK</h5>
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><router-link to="/">Home</router-link></li>
              <li class="breadcrumb-item" aria-current="page">{{ $route.name }}</li>
            </ol>
          </nav>
          <div class="content-product">
            <div class="row">
              <div class="col-md-12 col-card-product">
                <div class="row d-flex justify-content-center">
                  <div class="col-md-6">
                    <div v-if="not">
                      <div class="content-error">
                        <div class="img-error"><img src="../assets/img/notfound.png" alt="result not found" /></div>
                        <div class="desk-error">
                          <div class="title-error">Oops, produk nggak ditemukan</div>
                          <span class="desc-error">Coba cari produk lainnya.... </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="card-content card-content-all">
                  <div class="row-containerss">
                    <div class="product-card" v-for="product in products" :key="product.id">
                      <card-product-component :product="product" />
                    </div>
                  </div>
                  <div class="btn-load-more">
                    <button class="btn btn-success" v-if="products.length >= 20 && products.length < totalProducts" @click.prevent="loadMoreProducts()" :disabled="products.length >= totalProducts">Tampilkan Lebih Banyak</button>
                    <button class="btn btn-success" v-else disabled>Tidak Ada Produk Lain</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
// @ is an alias to /src
import apis from "@/apis";
import CardProductComponent from "@/components/CardProductComponent.vue";
import NavbarComponent from "@/components/NavbarComponent.vue";
export default {
  name: "ProductKategoriView",
  components: { CardProductComponent, NavbarComponent },
  metaInfo() {
    return {
      title: "Produk Gadgetcare",
    };
  },

  data() {
    return {
      products: {},
      not: false,
    };
  },

  created() {
    this.getProducts();
  },
  methods: {
    async getProducts() {
      try {
        const kategoriId = this.$route.params.id;
        const response = await apis.apis.post(
          apis.PublicPath + "/filter_produk",
          {
            kategori: kategoriId,
          },
          {
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
          }
        );
        this.products = response.data;
        this.not = false;
      } catch (error) {
        console.error(error);
        this.products = [];
        this.not = true;
      }
    },

    showAllProducts() {
      this.selectedcategory = null;
      this.getProducts();
    },
  },
};
</script>
<style>
.row-containerss {
  display: grid;
  grid-template-columns: repeat(5, 1fr) !important;
  grid-gap: 10px;
}
</style>
